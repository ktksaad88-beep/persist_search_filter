{
    'name': 'Persist Search Filter',
    'version': '19.0.1.0.0',
    'category': 'Technical',
    'summary': 'Keeps search filters persistent when navigating back to list/report views',
    'author': 'saad khattak',
    'depends': ['web', 'account'],
    'data': ['views/assets.xml'],
    'assets': {
        'web.assets_backend': [
            'persist_search_filter/static/src/js/persist_search_filter.js',
        ],
    },
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
