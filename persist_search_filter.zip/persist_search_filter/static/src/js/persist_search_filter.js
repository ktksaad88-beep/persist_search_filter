/** @odoo-module **/
const STORAGE_KEY_PREFIX = "odoo_persist_filter_";

function getStorageKey() {
    return STORAGE_KEY_PREFIX + btoa(window.location.pathname).replace(/=/g, "");
}

function saveSearchState(state) {
    try {
        sessionStorage.setItem(getStorageKey(), JSON.stringify(state));
    } catch (e) {
    }
}

function loadSearchState() {
    try {
        return JSON.parse(sessionStorage.getItem(getStorageKey()));
    } catch (e) {
        return null;
    }
}

function applyRestore(sv) {
    const saved = loadSearchState();
    if (!saved || !saved.searchString) return;
    if (sv.querySelector(".o_searchview_facet")) return;
    const input = sv.querySelector(".o_searchview_input");
    if (!input) return;

    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set;
    setter.call(input, saved.searchString);
    input.dispatchEvent(new Event("input", {bubbles: true}));

    // Immediately press Enter - don't wait for autocomplete at all
    input.dispatchEvent(new KeyboardEvent("keydown", {key: "Enter", keyCode: 13, bubbles: true}));


    let attempts = 0;
    const tryClick = setInterval(() => {
        attempts++;
        const first = document.querySelector(".o_searchview_autocomplete .o_menu_item");
        if (first) {
            clearInterval(tryClick);
            first.click();
        } else if (attempts > 5) {
            clearInterval(tryClick);
        }
    }, 20);
}

function initPersistFilter() {
    document.addEventListener("keyup", (e) => {
        const inp = e.target.closest(".o_searchview_input");
        if (inp) {
            const s = loadSearchState() || {};
            s.searchString = inp.value;
            saveSearchState(s);
        }
    }, true);

    document.addEventListener("click", (e) => {
        if (e.target.closest(".o_searchview_autocomplete") ||
            e.target.closest(".o_dropdown_item") ||
            e.target.closest(".o_menu_item")) {
            setTimeout(() => {
                const inp = document.querySelector(".o_searchview_input");
                if (inp) {
                    const s = loadSearchState() || {};
                    s.searchString = inp.value;
                    s.facets = [...document.querySelectorAll(".o_searchview_facet")].map(f => f.innerText.trim());
                    saveSearchState(s);
                }
            }, 100);
        }
        if (e.target.closest(".o_searchview_facet .o_delete") || e.target.closest(".o_clear_search")) {
            setTimeout(() => {
                if (!document.querySelector(".o_searchview_facet")) sessionStorage.removeItem(getStorageKey());
            }, 100);
        }
    }, true);


    let timer = null;
    new MutationObserver((mutations) => {
        for (const m of mutations) {
            for (const node of m.addedNodes) {
                if (node.nodeType !== 1) continue;
                const sv = node.classList?.contains("o_searchview")
                    ? node : node.querySelector?.(".o_searchview");
                if (!sv) continue;
                clearTimeout(timer);
                timer = setTimeout(() => applyRestore(sv), 0); // no delay at all
            }
        }
    }).observe(document.body, {childList: true, subtree: true});
}

if (document.body) initPersistFilter();
else document.addEventListener("DOMContentLoaded", initPersistFilter);
